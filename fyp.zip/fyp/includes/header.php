<!DOCTYPE html>
<html lang="en">
<head>
   
    
    <!-- Link to Custom CSS file -->
    <link rel="stylesheet" href="css/styles.css">

    <!-- Bootstrap CSS for layout and styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>



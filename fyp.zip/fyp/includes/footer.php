<footer>
    © 2024 School of Design & Arts
</footer>
